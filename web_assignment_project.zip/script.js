// Part 2: Functions — Scope, Parameters & Return Values

// Global variable
let globalMessage = "I am global!";

// Function demonstrating scope
function scopeDemo() {
  let localMessage = "I am local!";
  return `Global: ${globalMessage} | Local: ${localMessage}`;
}

// Function with parameters & return value
function calculateArea(width, height) {
  return width * height;
}

// Show scope demo in DOM
document.getElementById("scope-demo").textContent =
  scopeDemo() + " | Area of 5x10 = " + calculateArea(5, 10);

// Part 3: Combining CSS with JS

// Select elements
const animateBtn = document.getElementById("animateBtn");
const triggerBox = document.querySelector(".trigger-box");

// Function to toggle animation using classList
function toggleAnimation() {
  triggerBox.classList.toggle("active");
}

// Attach event listener
animateBtn.addEventListener("click", toggleAnimation);
